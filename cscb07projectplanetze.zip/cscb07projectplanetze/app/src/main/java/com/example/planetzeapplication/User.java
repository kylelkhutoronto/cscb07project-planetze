package com.example.planetzeapplication;
import java.util.*;
public class User {
    private String fullName;
    private String email;

    ArrayList<DayTracker> day;
    long totEmission;

    Boolean doneSurvey;

    HashMap<String, DayTracker> days;

    public User() {
    }

    public User(String fullName, String email, long totEmission) {
        this.fullName = fullName;
        this.email = email;
        this.totEmission = totEmission;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public Boolean getDoneSurvey() {
        return doneSurvey;
    }
    public Map<Long, Long> getEmissionsOverTime(long start_date, long end_date) {
        Map<Long, Long> emissionsOverTime = new TreeMap<>();
        if (days == null || days.isEmpty()) {
            return emissionsOverTime;
        }

        for (Map.Entry<String, DayTracker> entry : days.entrySet()) {
            try {

                long date = Long.parseLong(entry.getKey().replace("-", ""));
                if (date >= start_date && date <= end_date) {
                    emissionsOverTime.put(date, entry.getValue().totEmission);
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return emissionsOverTime;
    }

    // Method to Calculate Emissions by Category
    public Map<String, Long> getEmissionsByCategory() {
        Map<String, Long> emissionsByCategory = new HashMap<>();
        if (days == null || days.isEmpty()) {
            return emissionsByCategory;
        }

        for (DayTracker tracker : days.values()) {
            for (Map.Entry<String, Long> entry : tracker.log.entrySet()) {
                String category = entry.getKey();
                long emission = entry.getValue();

                emissionsByCategory.put(
                        category,
                        emissionsByCategory.getOrDefault(category, 0L) + emission
                );
            }
        }
        return emissionsByCategory;

}

