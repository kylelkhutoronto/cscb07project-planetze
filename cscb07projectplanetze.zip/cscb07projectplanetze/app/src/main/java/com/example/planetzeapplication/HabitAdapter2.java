package com.example.planetzeapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HabitAdapter2 extends RecyclerView.Adapter<HabitAdapter2.HabitsViewHolder> {

    private final ArrayList<Activity> activities;
    private final OnAddToTrackingListener habitActionListener; // Interface to handle button clicks

    // Constructor now includes the listener
    public HabitAdapter2(ArrayList<Activity> activities, OnAddToTrackingListener habitActionListener) {
        this.activities = activities;
        this.habitActionListener = habitActionListener;
    }

    @NonNull
    @Override
    public HabitsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.habit_layout, parent, false);
        return new HabitsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HabitsViewHolder holder, int position) {
        Activity activity = activities.get(position);
        holder.activityName.setText(activity.getActivityName());
        holder.activityCategory.setText(activity.getCategory());
        holder.activityEmission.setText(String.valueOf(activity.getEmission()));

        holder.btnAddToTracking.setOnClickListener(v -> {
            if (habitActionListener != null) {
                habitActionListener.onAddToTracking(activity); // Notify listener
            }
        });
    }

    @Override
    public int getItemCount() {
        return activities.size();
    }

    static class HabitsViewHolder extends RecyclerView.ViewHolder {
        TextView activityName, activityCategory, activityEmission;
        Button btnAddToTracking;  // The "Add Habit" button

        public HabitsViewHolder(@NonNull View itemView) {
            super(itemView);
            activityName = itemView.findViewById(R.id.activityName);
            activityCategory = itemView.findViewById(R.id.activityCategory);
            activityEmission = itemView.findViewById(R.id.activityEmission);
            btnAddToTracking = itemView.findViewById(R.id.button1);  // Add Habit button
        }
    }

    // Callback interface to notify the fragment or activity when the button is clicked
    public interface OnAddToTrackingListener {
        void onAddToTracking(Activity activity);
    }

    // Method to update the list with a filtered list
    public void updateList(ArrayList<Activity> filteredList) {
        activities.clear();
        activities.addAll(filteredList);
        notifyDataSetChanged();
    }
}