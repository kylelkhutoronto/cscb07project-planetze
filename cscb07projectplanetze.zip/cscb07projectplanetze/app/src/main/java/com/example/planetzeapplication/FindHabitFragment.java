
package com.example.planetzeapplication;

import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FindHabitFragment extends Fragment implements HabitAdapter2.OnAddToTrackingListener {

    private RecyclerView recyclerView;
    private HabitAdapter2 habitAdapter2;
    private ArrayList<Activity> habitsList;
    private Spinner spinnerCategory, spinnerImpact;
    private EditText searchBar;

    private FirebaseDatabase db;
    private DatabaseReference habitsRef;
    private FirebaseAuth auth;
    private String uid, category, impact;
    final int numOfActivities = 7;
    private Handler handler = new Handler();
    private Runnable filterRunnable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_find_habits, container, false);

        searchBar = view.findViewById(R.id.search_bar);
        recyclerView = view.findViewById(R.id.habit_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        spinnerCategory = view.findViewById(R.id.spinnerCategory);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getContext(),
                R.array.category_options, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter1);

        spinnerImpact = view.findViewById(R.id.spinnerImpact);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(getContext(),
                R.array.impact_options, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerImpact.setAdapter(adapter2);

        habitsList = new ArrayList<>();
        habitAdapter2 = new HabitAdapter2(habitsList, this); // Pass this fragment as the listener
        recyclerView.setAdapter(habitAdapter2);

        auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();
        uid = currentUser.getUid();

        db = FirebaseDatabase.getInstance();
        habitsRef = db.getReference("Users").child(uid);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString().toLowerCase();
                if (category.equals("Filter by Category")) category = null;
                fetchHabitsFromDatabase(category, impact);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        spinnerImpact.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                impact = parent.getItemAtPosition(position).toString().toLowerCase();
                if (impact.equals("Filter by Impact")) impact = null;
                fetchHabitsFromDatabase(category, impact);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (filterRunnable != null) {
                    handler.removeCallbacks(filterRunnable);
                }

                filterRunnable = () -> filterHabits(s.toString());
                handler.postDelayed(filterRunnable, 300); // Delay of 300 ms
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Do nothing
            }
        });

        return view;
    }

    @Override
    public void onAddToTracking(Activity activity) {
        // Handle adding the activity to tracking
        activity.setTracking(true); // Mark activity as tracking
        activity.updateHabit(activity.getActivityId()); // Update the habit in Firebase
        Toast.makeText(getContext(), activity.getActivityName() + " added to tracking!", Toast.LENGTH_SHORT).show();
    }

    private void fetchHabitsFromDatabase(String category, String impact) {
        habitsRef = db.getReference("Activities");

        Query query = habitsRef;
        if (category != null) {
            query = query.orderByChild("category").equalTo(category);
        }
        if (impact != null) {
            try {
                Double impactValue = Double.parseDouble(impact);
                query = query.orderByChild("baseEmission").equalTo(impactValue);
            } catch (NumberFormatException e) {
                Log.e("FindHabitFragment", "Invalid impact value: " + impact);
            }
        }

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                habitsList.clear();

                for (DataSnapshot activitySnapshot : dataSnapshot.getChildren()) {
                    Activity habit = activitySnapshot.getValue(Activity.class);
                    if (habit != null && habit.isTracking()) {
                        habitsList.add(habit);
                    }
                }

                // Notify adapter of the changes
                habitAdapter2.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Firebase", "Error fetching data", databaseError.toException());
            }
        });
    }

    private void filterHabits(String query) {
        ArrayList<Activity> filteredList = new ArrayList<>();

        for (Activity habit : habitsList) {
            if (habit.getActivityName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(habit);
            }
        }

        // Update the adapter with the filtered list
        habitAdapter2.updateList(filteredList);
    }
}

